package com;

import java.awt.EventQueue;
import java.awt.print.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTextArea;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JCheckBox;
import javax.swing.JRadioButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import java.awt.Color;
//import javax.swing.ButtonGroup;

public class OrderUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField lbEgg;
	private JTextField lbOmelet;
	private JTextField lbMilkTea;
	private JTextField tfNote;
	private JRadioButton nMember;
	private JRadioButton gMember;
	//private final ButtonGroup buttonGroup = new ButtonGroup();
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					OrderUI frame = new OrderUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public OrderUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 501, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 128, 192));
		panel.setBounds(10, 10, 465, 65);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("BreakFast 點 餐 系 統");
		lblNewLabel.setFont(new Font("新細明體", Font.PLAIN, 24));
		lblNewLabel.setBounds(115, 10, 249, 45);
		panel.add(lblNewLabel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(10, 85, 465, 296);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("荷包蛋");
		lblNewLabel_1.setBounds(47, 82, 46, 15);
		panel_1.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("蛋餅");
		lblNewLabel_2.setBounds(47, 130, 56, 15);
		panel_1.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("奶茶");
		lblNewLabel_3.setBounds(47, 179, 46, 15);
		panel_1.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("顆(15元)");
		lblNewLabel_4.setBounds(293, 82, 71, 15);
		panel_1.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("份(60元)");
		lblNewLabel_5.setBounds(293, 130, 62, 15);
		panel_1.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("杯(30元)");
		lblNewLabel_6.setBounds(293, 179, 71, 15);
		panel_1.add(lblNewLabel_6);
		
		lbEgg = new JTextField();
		lbEgg.setEditable(false);
		lbEgg.setText("0");
		lbEgg.setBounds(163, 79, 51, 21);
		panel_1.add(lbEgg);
		lbEgg.setColumns(10);
		
		lbOmelet = new JTextField();
		lbOmelet.setEditable(false);
		lbOmelet.setText("0");
		lbOmelet.setBounds(163, 127, 51, 21);
		panel_1.add(lbOmelet);
		lbOmelet.setColumns(10);
		
		lbMilkTea = new JTextField();
		lbMilkTea.setEditable(false);
		lbMilkTea.setText("0");
		lbMilkTea.setBounds(163, 176, 51, 21);
		panel_1.add(lbMilkTea);
		lbMilkTea.setColumns(10);
				
		JLabel lblNewLabel_7 = new JLabel("桌號");
		lblNewLabel_7.setBounds(47, 31, 46, 15);
		panel_1.add(lblNewLabel_7);
		
		tfNote = new JTextField();
		tfNote.setColumns(10);
		tfNote.setBounds(103, 213, 244, 21);
		panel_1.add(tfNote);
		
		JLabel lblNewLabel_8 = new JLabel("特殊需求:");
		lblNewLabel_8.setBounds(47, 216, 71, 15);
		panel_1.add(lblNewLabel_8);
				
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(10, 391, 465, 161);
		contentPane.add(panel_2);
		panel_2.setLayout(null);
		
		JTextArea txrOutput = new JTextArea();
		txrOutput.setBounds(10, 10, 445, 141);
		panel_2.add(txrOutput);
		
		
		//****選項區****
		gMember = new JRadioButton("白金會員(6折)");
		//buttonGroup.add(gMember);
		gMember.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(gMember.isSelected())
					nMember.setSelected(false);	
			}
		});
		gMember.setEnabled(false);
		gMember.setBounds(358, 67, 107, 23);
		panel_1.add(gMember);
		
		nMember = new JRadioButton("一般會員(8折)");
		//buttonGroup.add(nMember);
		nMember.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(nMember.isSelected())
					gMember.setSelected(false);	
			}
		});
		nMember.setEnabled(false);
		nMember.setBounds(358, 96, 107, 23);
		panel_1.add(nMember);
		
		
		JCheckBox ckbMember = new JCheckBox("會員");
		ckbMember.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(ckbMember.isSelected())
				{
					gMember.setEnabled(true);
					nMember.setEnabled(true);
					nMember.setSelected(true);
				}
				else
				{
					gMember.setSelected(false);
					gMember.setEnabled(false);
					nMember.setSelected(false);
					nMember.setEnabled(false);
					
				}
			}
		});

		ckbMember.setBounds(351, 42, 97, 23);
		panel_1.add(ckbMember);

		JComboBox<String> btmNumber = new JComboBox<>();
		btmNumber.setBounds(103, 27, 71, 23);
		panel_1.add(btmNumber);
		btmNumber.addItem("A桌");
		btmNumber.addItem("B桌");
		btmNumber.addItem("C桌");
		
		
		//****按鈕區****
		
		
		JButton btmExit = new JButton("離開");
		btmExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btmExit.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(0);
			}
		});
		btmExit.setBounds(367, 263, 87, 23);
		panel_1.add(btmExit);
		
		JButton btmClear = new JButton("清除");
		btmClear.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				tfNote.setText("");
				lbEgg.setText("0");
				lbOmelet.setText("0");
				lbMilkTea.setText("0");
				txrOutput.setText("");
				ckbMember.setSelected(false);
				gMember.setSelected(false);
				gMember.setEnabled(false);
				nMember.setSelected(false);
				nMember.setEnabled(false);
			}
		});
		btmClear.setBounds(139, 263, 87, 23);
		panel_1.add(btmClear);
		
		JButton btmOK = new JButton("送單");
		btmOK.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				String cb=String.valueOf(btmNumber.getSelectedItem());
				int eg=Integer.parseInt(lbEgg.getText());
				int om=Integer.parseInt(lbOmelet.getText());
				int mk=Integer.parseInt(lbMilkTea.getText());
				boolean gme=gMember.isSelected();
				boolean nme=nMember.isSelected();
				String no=tfNote.getText();
				Order or=new Order(cb,eg,om,mk,gme,nme,no);
				txrOutput.setText(or.show());

			}
		});
		btmOK.setBounds(27, 263, 87, 23);
		panel_1.add(btmOK);
		
		JButton eggAdd = new JButton("+");
		eggAdd.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int eg2=Integer.parseInt(lbEgg.getText());
				eg2++;
				lbEgg.setText(eg2+"");
			}
		});
		eggAdd.setBounds(224, 79, 46, 21);
		panel_1.add(eggAdd);
		
		JButton eggSub = new JButton("-");
		eggSub.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int x=Integer.parseInt(lbEgg.getText());
				if(x>0)
				x--;
				lbEgg.setText(x+"");
			}
		});
		eggSub.setBounds(103, 78, 46, 22);
		panel_1.add(eggSub);
		
		JButton omeletAdd = new JButton("+");
		omeletAdd.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int x=Integer.parseInt(lbOmelet.getText());
				x++;
				lbOmelet.setText(x+"");
			}
		});
		omeletAdd.setBounds(224, 127, 46, 21);
		panel_1.add(omeletAdd);
		
		JButton omeletSub = new JButton("-");
		omeletSub.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int x=Integer.parseInt(lbOmelet.getText());
				if(x>0)
				x--;
				lbOmelet.setText(x+"");
			}
		});
		omeletSub.setBounds(103, 126, 46, 22);
		panel_1.add(omeletSub);
		
		JButton milkTeaAdd = new JButton("+");
		milkTeaAdd.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int x=Integer.parseInt(lbMilkTea.getText());
				x++;
				lbMilkTea.setText(x+"");
			}
		});
		milkTeaAdd.setBounds(224, 176, 46, 21);
		panel_1.add(milkTeaAdd);
		
		JButton milkTeaSub = new JButton("-");
		milkTeaSub.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int x=Integer.parseInt(lbMilkTea.getText());
				if(x>0)
				x--;
				lbMilkTea.setText(x+"");
			}
		});
		milkTeaSub.setBounds(103, 175, 46, 22);
		panel_1.add(milkTeaSub);
		
		JButton btnPrint = new JButton("列印");
		btnPrint.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					txrOutput.print();
				} catch (PrinterException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnPrint.setBounds(260, 263, 87, 23);
		panel_1.add(btnPrint);
		
		
		

	}
}
