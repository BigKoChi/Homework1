package com;

public class Order {
	//field
	private String number;
	private int egg;
	private int omelet;
	private int milkTea;
	private boolean gmember,nmember;
	private double sum;
	private String note;
	
	//constructor
	Order(String number,int egg,int omelet,int milkTea,boolean gmember,boolean nmember,String note)
	{
		this.number=number;
		this.egg=egg;
		this.omelet=omelet;
		this.milkTea=milkTea;
		this.gmember=gmember;
		this.nmember=nmember;
		this.note=note;
		if(gmember)
			sum=(egg*15+omelet*60+milkTea*30)*0.6;
		else if(nmember)
			sum=(egg*15+omelet*60+milkTea*30)*0.8;
		else
			sum=egg*15+omelet*60+milkTea*30;
	}
	
	//method
	
	
	String show() 
	{
		return("桌號:"+number+
		"\n荷包蛋:"+egg+"顆"+
		"\n蛋餅:"+omelet+"份"+
		"\n奶茶:"+milkTea+"杯"+
		"\n總計:"+sum+"元"+
		"\n特殊需求:"+note);
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public int getEgg() {
		return egg;
	}

	public void setEgg(int egg) {
		this.egg = egg;
	}

	public int getOmelet() {
		return omelet;
	}

	public void setOmelet(int omelet) {
		this.omelet = omelet;
	}

	public int getMilkTea() {
		return milkTea;
	}

	public void setMilkTea(int milkTea) {
		this.milkTea = milkTea;
	}

	public boolean isGmember() {
		return gmember;
	}

	public void setGmember(boolean gmember) {
		this.gmember = gmember;
	}

	public boolean isNmember() {
		return nmember;
	}

	public void setNmember(boolean nmember) {
		this.nmember = nmember;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public double getSum() {
		return sum;
	}
}
